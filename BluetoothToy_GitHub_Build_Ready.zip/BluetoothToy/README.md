# Bluetooth Toy

A small Android BLE advertising/scanning toy with a glitch-heavy WebView UI.

## What is real

- BLE scanning uses Android BluetoothLeScanner.
- BLE advertising uses Android BluetoothLeAdvertiser.
- Runtime Nearby Devices permissions are requested on Android 12+.
- The advertised local name is temporarily changed to the requested name and restored when advertising stops.
- Scan results show the advertised device name when the scanner receives one.

## Important Android behavior

This is BLE advertising, not unrestricted Bluetooth Classic discoverability. A BLE scanner is the most reliable way to see the advertisement. Some normal Bluetooth Settings screens may not list BLE advertisements as ordinary pairable devices.

The phone must support BLE advertising. Some phones expose BLE scanning but do not support peripheral/advertising mode.

## Build

Open this folder in Android Studio and let Gradle sync. Build/install the debug APK.

The project intentionally avoids third-party runtime libraries so the Bluetooth layer stays small.
