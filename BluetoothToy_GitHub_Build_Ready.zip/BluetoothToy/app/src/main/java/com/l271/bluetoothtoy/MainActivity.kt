package com.l271.bluetoothtoy

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val adapter: BluetoothAdapter? by lazy {
        val manager = getSystemService(BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager
        manager.adapter
    }

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var advertiseCallback: AdvertiseCallback? = null
    private var scanCallback: ScanCallback? = null
    private var oldAdapterName: String? = null
    private var advertising = false
    private var scanning = false

    companion object {
        private const val REQ_BT = 4101
        private const val REQ_ENABLE = 4102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(BluetoothBridge(), "AndroidBluetooth")
            loadUrl("file:///android_asset/index.html")
        }

        setContentView(web)
    }

    private fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun hasPermissions(): Boolean =
        requiredPermissions().all {
            Build.VERSION.SDK_INT < 23 ||
                checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
        }

    private fun ensureBluetoothReady(action: () -> Unit) {
        if (adapter == null) {
            jsError("This phone does not provide Bluetooth.")
            return
        }
        if (!hasPermissions()) {
            requestPermissions(requiredPermissions(), REQ_BT)
            return
        }
        if (!adapter!!.isEnabled) {
            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE)
            return
        }
        action()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, results: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == REQ_BT) {
            if (results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) {
                jsStatus("READY")
            } else {
                jsError("Nearby Bluetooth permission was denied.")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ENABLE) {
            if (resultCode == RESULT_OK) jsStatus("READY")
            else jsError("Bluetooth must be enabled first.")
        }
    }

    private fun startAdvertising() {
        ensureBluetoothReady {
            if (advertising) return@ensureBluetoothReady

            if (!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
                jsError("BLE is not supported on this phone.")
                return@ensureBluetoothReady
            }

            advertiser = adapter!!.bluetoothLeAdvertiser
            if (advertiser == null) {
                jsError("BLE advertising is not available on this phone.")
                return@ensureBluetoothReady
            }

            // WebView JavaScript evaluation is asynchronous; read the name
            // in its callback, then start the native advertiser.
            web.evaluateJavascript(
                "(function(){return document.getElementById('name').value})()"
            ) { raw ->
                val name = raw.trim('"').replace("\\\"", "\"").take(24).ifBlank { "L271_NODE" }
                doStartAdvertising(name)
            }
        }
    }

    private fun doStartAdvertising(name: String) {
        if (!hasPermissions()) {
            jsError("Bluetooth permission is missing.")
            return
        }

        try {
            oldAdapterName = adapter!!.name
            // Android advertises the adapter's local name when includeDeviceName=true.
            // Restore it when advertising stops.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                jsError("Bluetooth Connect permission is required to set the advertised name.")
                return
            }

            adapter!!.name = name

            val settings = AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                .setConnectable(false)
                .setTimeout(0)
                .build()

            val data = AdvertiseData.Builder()
                .setIncludeDeviceName(true)
                .setIncludeTxPowerLevel(false)
                .build()

            advertiseCallback = object : AdvertiseCallback() {
                override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                    advertising = true
                    jsStatus("ADVERTISING")
                }

                override fun onStartFailure(errorCode: Int) {
                    advertising = false
                    restoreName()
                    jsError("BLE advertising failed: ${advertiseError(errorCode)}")
                }
            }

            advertiser!!.startAdvertising(settings, data, advertiseCallback)
        } catch (e: SecurityException) {
            jsError("Bluetooth permission blocked the operation.")
        } catch (e: Exception) {
            jsError(e.message ?: "Could not start BLE advertising.")
        }
    }

    private fun stopAdvertising() {
        if (!advertising && advertiseCallback == null) return
        try {
            if (hasPermissions()) {
                advertiser?.stopAdvertising(advertiseCallback)
            }
        } catch (_: Exception) {}
        advertising = false
        advertiseCallback = null
        restoreName()
        jsStatus(if (scanning) "SCANNING" else "STANDBY")
    }

    private fun restoreName() {
        val old = oldAdapterName ?: return
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                adapter?.name = old
            }
        } catch (_: Exception) {}
        oldAdapterName = null
    }

    private fun startScan() {
        ensureBluetoothReady {
            if (scanning) return@ensureBluetoothReady
            scanner = adapter!!.bluetoothLeScanner
            if (scanner == null) {
                jsError("BLE scanner is not available.")
                return@ensureBluetoothReady
            }

            scanCallback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val device: BluetoothDevice = result.device
                    val name = result.scanRecord?.deviceName
                        ?: try { device.name } catch (_: Exception) { null }
                        ?: "UNKNOWN_DEVICE"
                    val address = try { device.address } catch (_: Exception) { "UNKNOWN" }
                    val rssi = result.rssi
                    jsDevice(name, address, rssi)
                }

                override fun onScanFailed(errorCode: Int) {
                    scanning = false
                    jsError("BLE scan failed: ${scanError(errorCode)}")
                }
            }

            try {
                scanner!!.startScan(scanCallback)
                scanning = true
                jsStatus("SCANNING")
            } catch (e: SecurityException) {
                jsError("Bluetooth scan permission blocked the operation.")
            } catch (e: Exception) {
                jsError(e.message ?: "Could not start BLE scan.")
            }
        }
    }

    private fun stopScan() {
        if (!scanning) return
        try {
            if (hasPermissions()) scanner?.stopScan(scanCallback)
        } catch (_: Exception) {}
        scanning = false
        scanCallback = null
        jsStatus(if (advertising) "ADVERTISING" else "STANDBY")
    }

    override fun onDestroy() {
        stopScan()
        stopAdvertising()
        web.removeJavascriptInterface("AndroidBluetooth")
        web.destroy()
        super.onDestroy()
    }

    private fun jsStatus(status: String) {
        runOnUiThread {
            web.evaluateJavascript("nativeStatus(${jsString(status)})", null)
        }
    }

    private fun jsError(message: String) {
        runOnUiThread {
            web.evaluateJavascript("nativeError(${jsString(message)})", null)
        }
    }

    private fun jsDevice(name: String, address: String, rssi: Int) {
        runOnUiThread {
            web.evaluateJavascript(
                "device(${jsString(name)},${jsString(address)},$rssi)",
                null
            )
        }
    }

    private fun jsString(value: String): String =
        "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun advertiseError(code: Int): String = when (code) {
        AdvertiseCallback.ADVERTISE_FAILED_ALREADY_STARTED -> "already started"
        AdvertiseCallback.ADVERTISE_FAILED_DATA_TOO_LARGE -> "data too large"
        AdvertiseCallback.ADVERTISE_FAILED_FEATURE_UNSUPPORTED -> "feature unsupported"
        AdvertiseCallback.ADVERTISE_FAILED_INTERNAL_ERROR -> "internal error"
        AdvertiseCallback.ADVERTISE_FAILED_TOO_MANY_ADVERTISERS -> "too many advertisers"
        else -> "code $code"
    }

    private fun scanError(code: Int): String = when (code) {
        ScanCallback.SCAN_FAILED_ALREADY_STARTED -> "already started"
        ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED -> "application registration failed"
        ScanCallback.SCAN_FAILED_INTERNAL_ERROR -> "internal error"
        ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED -> "feature unsupported"
        else -> "code $code"
    }

    inner class BluetoothBridge {
        @JavascriptInterface
        fun startAdvertising() {
            runOnUiThread { startAdvertising() }
        }

        @JavascriptInterface
        fun stopAdvertising() {
            runOnUiThread { stopAdvertising() }
        }

        @JavascriptInterface
        fun startScan() {
            runOnUiThread { startScan() }
        }

        @JavascriptInterface
        fun stopScan() {
            runOnUiThread { stopScan() }
        }
    }
}
