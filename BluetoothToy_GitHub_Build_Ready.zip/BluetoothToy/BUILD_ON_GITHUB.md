# Build Bluetooth Toy on GitHub

1. Create a new GitHub repository.
2. Upload the contents of this project to the repository root.
3. Open the **Actions** tab.
4. Select **Build Bluetooth Toy APK**.
5. Choose **Run workflow**.
6. When it finishes, open the workflow run.
7. Under **Artifacts**, download **Bluetooth-Toy-debug**.
8. Extract it to get `app-debug.apk`.

The workflow builds the debug APK entirely on GitHub's hosted runner.
